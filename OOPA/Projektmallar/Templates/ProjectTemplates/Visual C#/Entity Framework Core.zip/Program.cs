﻿namespace $safeprojectname$
{
    using System;

    /// <summary>
    /// Defines the <see cref="Program" />.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// The Main method.
        /// </summary>
        internal static void Main()
        {
            Console.WriteLine(" _     _ _______                _____     _______ _______ ");
            Console.WriteLine(" |_____| |______ |      |      |     |   |______ |______  ");
            Console.WriteLine(" |     | |______ |_____ |_____ |_____|   |______ |        ");
            Console.WriteLine("                                                          ");
            Console.WriteLine(" Project: $projectname$");
            Console.WriteLine(" Project by $username$, created $time$");
        }
    }
}
