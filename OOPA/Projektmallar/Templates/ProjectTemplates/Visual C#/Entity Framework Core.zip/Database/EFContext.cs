﻿namespace $safeprojectname$.Database
{
    using $safeprojectname$.Models;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Defines the <see cref="$safeprojectname$Context" />.
    /// </summary>
    public class $safeprojectname$Context : DbContext
    {
        /// <summary>
        /// Defines the DatabaseName.
        /// </summary>
        private const string DatabaseName = "$safeprojectname$DB";

        /// <summary>
        /// The MyModels DBSet.
        /// </summary>
        public DbSet<$safeprojectname$Model> $safeprojectname$Models { get; set; }

        /// <summary>
        /// The OnConfiguring method.
        /// </summary>
        /// <param name="optionsBuilder">The optionsBuilder<see cref="DbContextOptionsBuilder"/>.</param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer($@"Server=.\SQLEXPRESS;Database={DatabaseName}; Trusted_Connection = true;");
        }
    }
}
