﻿namespace $rootnamespace$
{
    using Doobeedoo.Models;
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// Defines the <see cref="$safeitemname$" />.
    /// </summary>
    public class $safeitemname$ : DbContext
    {
        /// <summary>
        /// Defines the DatabaseName.
        /// </summary>
        private const string DatabaseName = "$fileinputname$Db";

        /// <summary>
        /// The MyModels DBSet.
        /// </summary>
        public DbSet<$fileinputname$Model> $fileinputname$s { get; set; }

        /// <summary>
        /// The OnConfiguring method.
        /// </summary>
        /// <param name="optionsBuilder">The optionsBuilder<see cref="DbContextOptionsBuilder"/>.</param>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer($@"Server=.\SQLEXPRESS;Database={DatabaseName}; Trusted_Connection = true;");
        }
    }
}
