﻿namespace MyNamespace
{
    using MyNamespace.Models;
using Microsoft.EntityFrameworkCore;

public class MyContext : DbContext
{
    private const string DatabaseName = "ModelsDB";
    public DbSet<MyModel> Models { get; set; }
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer($@"Server=.\SQLEXPRESS;Database={DatabaseName}; Trusted_Connection = true;");
    }
}
}
