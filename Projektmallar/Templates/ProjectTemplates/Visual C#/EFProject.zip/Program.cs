﻿namespace MyNamespace
{
    using System;

    /// <summary>
    /// Defines the <see cref="Program" />.
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// The Main method.
        /// </summary>
        internal static void Main()
        {
            Console.WriteLine(" _     _ _______                _____     _______ _______ ");
            Console.WriteLine(" |_____| |______ |      |      |     |   |______ |______  ");
            Console.WriteLine(" |     | |______ |_____ |_____ |_____|   |______ |        ");
            Console.WriteLine("                                                          ");
            Console.WriteLine(" Project: $safeprojectname$");
            Console.WriteLine(" Project by marcu, created 2/24/2021 10:32:25 PM");


        }
    }
}
